package com.gjt.chat.entity;

/**
 * @author 官江涛
 * @version 1.0
 * @Title: 通用id查找工具
 * @date 2018/6/1/10:40
 */
public class GetByIdDTO {

    /**
     * 根据id查找
     */
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
