package com.gjt.chatClient.ui.chatui;

/**
 * @author 官江涛
 * @version 1.0
 * @Title:  聊天窗口
 * @date 2018/6/8/11:46
 */
public class ChatPanel {
}
